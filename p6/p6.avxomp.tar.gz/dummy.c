#include "precision.h"      /* chus */

int dummy(real a[], real b[], real c[], real t)
{
    // --  called in each loop to make all computations appear required
	return 0;
}
